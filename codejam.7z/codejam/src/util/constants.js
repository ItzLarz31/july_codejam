export const swimming = [
  {
    id: 1,
    name: "Ocean",
    image: "insert image here",
    info: "Its a big ocean with lots of fish",
  },
];

export const themeParks = [
  {
    id: 1,
    name: "Disney World",
    image: "insert image here",
    info: "Its a big theme park with lots of rides",
  },
];
